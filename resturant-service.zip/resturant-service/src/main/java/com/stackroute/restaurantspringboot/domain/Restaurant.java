package com.stackroute.restaurantspringboot.domain;


import javax.annotation.Generated;
import javax.validation.constraints.NotNull;

//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Indexed;

public class Restaurant {
	
	private int id;
	
	private String name;
	
	private String imageLink;
	
	private String cuizine;
	
	private String review;
	
	private String address;
	
	public Restaurant() {
		// TODO Auto-generated constructor stub
	}
	
	public Restaurant(String name,String imageLink,String cuizine,String review,String address) {
		// TODO Auto-generated constructor stub
		this.name=name;
		this.imageLink=imageLink;
		this.cuizine=cuizine;
		this.review=review;
		this.address=address;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		
		this.address = address;
		
	}

	public int getId() {
		
		return id;
		
	}

	public void setId(int id) {
		
		this.id = id;
	
	}

	public String getName() {
	
		return name;
	
	}

	public void setName(String name) {
	
		this.name = name;
	
	}

	public String getImageLink() {
	
		return imageLink;
	
	}

	public void setImageLink(String imageLink) {
	
		this.imageLink = imageLink;
	
	}

	public String getCuizine() {
	
		return cuizine;
	
	}

	public void setCuizine(String cuizine) {
	
		this.cuizine = cuizine;
	
	}

	public String getReview() {
	
		return review;
	
	}

	public void setReview(String review) {
	
		this.review = review;
	
	}

}
